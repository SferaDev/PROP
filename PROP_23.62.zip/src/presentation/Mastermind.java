package presentation;

public interface Mastermind {
    void startApplication();
    void setInputOutPut();
}
