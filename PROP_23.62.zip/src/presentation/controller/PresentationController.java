package presentation.controller;

public class PresentationController {
    private static PresentationController mInstance = new PresentationController();

    public static PresentationController getInstance() {
        return mInstance;
    }

    private BoardController currentBoard;

    private PresentationController() {
    }

    public BoardController getCurrentBoard() {
        return currentBoard;
    }

    public void setCurrentBoard(BoardController currentBoard) {
        this.currentBoard = currentBoard;
    }
}
