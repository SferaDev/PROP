package presentation;

public class TestMastermind implements Mastermind {
    @Override
    public void startApplication() {
        // TODO
    }

    @Override
    public void setInputOutPut() {
        // TODO
    }
}
