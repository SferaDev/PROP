package presentation;

public class TestMastermind implements Mastermind {
    @Override
    public void startApplication() {
        // TODO
    }
}
