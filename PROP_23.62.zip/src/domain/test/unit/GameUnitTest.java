package domain.test.unit;

/**
 * The type Game unit test.
 *
 * @author Oriol Borrell Roig
 */
public class GameUnitTest {
}
