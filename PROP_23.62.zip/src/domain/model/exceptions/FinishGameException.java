package domain.model.exceptions;

public class FinishGameException extends Exception {

    public FinishGameException() {
        super();
    }
}
