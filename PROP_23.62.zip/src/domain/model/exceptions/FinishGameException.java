package domain.model.exceptions;

/**
 * Treats finish game exception
 */
public class FinishGameException extends Exception {

    public FinishGameException() {
        super();
    }
}
