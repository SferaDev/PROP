package presentation;

/**
 * The type Visual mastermind.
 *
 * @author Alexis Rico Carreto
 */
public class VisualMastermind implements Mastermind {
    @Override
    public void startApplication() {
        // TODO: Placeholder to store the Graphic version of Mastermind (Entrega 2)
    }

    @Override
    public void setInputOutPut() {
        // TODO
    }
}
