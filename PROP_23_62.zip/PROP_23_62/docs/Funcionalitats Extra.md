# Funcionalitats extra: 

1.	Per organitzar les partides, hem implementat un sistema de control de usuaris amb l'opció de fer login al sistema.

2.	Els diferents nivells de dificultat els apliquem donant a escollir el numero de fitxes i colors amb els quals es vol jugar una partida.

3.	Hem programat dos algoritmes per jugar contra la CPU. L'usuari pot seleccionar tant el FiveGuess com el Genetic.

4.	Els algoritmes s’executen en un thread en background separat del thread principal que controla la interficie d'usuari.

5.	Oferim a l'usuari la possibilitat de canviar contrasenya.

6.	Oferim a l'usuari la possibilitat de canviar l’idioma de la aplicació entre Català, Castellà o Anglès.

7.	Oferim a l'usuari la possibilitat de jugar via terminal (Command Line Interface).
