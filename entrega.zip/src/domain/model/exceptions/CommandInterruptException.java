package domain.model.exceptions;

public class CommandInterruptException extends Exception {

    public CommandInterruptException() {
        super();
    }
}
