package presentation;

public class VisualMastermind implements Mastermind {
    @Override
    public void startApplication() {
        // TODO: Placeholder to store the Graphic version of Mastermind (Entrega 2)
    }
}
